package megateam.megamanxrpg;

public class ServerProxy {
	public void registerRenderThings()
	{

	}
}